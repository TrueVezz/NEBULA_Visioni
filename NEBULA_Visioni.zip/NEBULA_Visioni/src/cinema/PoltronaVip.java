package cinema;

import java.io.Serializable;

public class PoltronaVip extends Poltrona implements Serializable {

    private static final int prezzoVip = 15;
    private static final String COLOR = "YELLOW";

    public static int getPrezzoVip() {
        return prezzoVip;
    }

    public PoltronaVip(char fila, int numero) {
        super(fila, numero);
    }
}
