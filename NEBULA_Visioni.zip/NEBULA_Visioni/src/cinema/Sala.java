package cinema;

import java.io.Serializable;

public class Sala implements Serializable {

    private Poltrona[][] poltrone;

    public Sala() {
        poltrone = new Poltrona[6][16];
        for (int i = 0; i < 6; i++) {
            char fila = (char) ('A' + i);
            for (int j = 0; j < 16; j++) {
                if (i < 2) {
                    poltrone[i][j] = new Poltrona(fila, j); // A-B
                } else if (i < 4) {
                    poltrone[i][j] = new PoltronaReclinabile(fila, j); // C-D
                } else {
                    poltrone[i][j] = new PoltronaVip(fila, j); // E-F
                }
            }
        }
    }

    public int bookSeat(String fila, int num) {
        int row = fila.toUpperCase().charAt(0) - 'A';
        if (!poltrone[row][num].isOccupata()) {
            poltrone[row][num].changeState();
            return 0;
        }
        return -1;
    }

    public String printSeat() {
        String result = "   ";
        for (int i = 0; i < 16; i++) {
            result += String.format("%2d ", i);
        }
        result += "\n";

        for (int i = 0; i < poltrone.length; i++) {
            result += (char) ('A' + i) + ": ";
            for (int j = 0; j < poltrone[i].length; j++) {
                result += poltrone[i][j].isOccupata() ? " x " : " o ";
            }
            result += "\n";
        }

        return result;
    }

    public int getPriceOfSeat(String fila, int num) {
        int row = fila.toUpperCase().charAt(0) - 'A';
        Poltrona p = poltrone[row][num];

        if (p instanceof PoltronaVip) {
            return PoltronaVip.getPrezzoVip();
        } else if (p instanceof PoltronaReclinabile) {
            return PoltronaReclinabile.getPrezzoReclinabile();
        } else {
            return Poltrona.getPrezzo();
        }
    }

    public boolean isSeatOccupied(String fila, int num) {
        int row = fila.toUpperCase().charAt(0) - 'A';
        return poltrone[row][num].isOccupata();
    }

}
