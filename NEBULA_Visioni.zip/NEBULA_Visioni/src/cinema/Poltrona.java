package cinema;

import java.io.Serializable;

public class Poltrona implements Serializable {

    private char fila;
    private int numero;
    private static int prezzo = 5;
    private boolean occupata = false;

    public static int getPrezzo() {
        return prezzo;
    }

    public Poltrona(char fila, int numero) {
        this.fila = fila;
        this.numero = numero;
    }

    public char getFila() {
        return fila;
    }

    public void setFila(char fila) {
        this.fila = fila;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public boolean isOccupata() {
        return occupata;
    }

    public void changeState() {
        this.occupata = !this.occupata;
    }
}
