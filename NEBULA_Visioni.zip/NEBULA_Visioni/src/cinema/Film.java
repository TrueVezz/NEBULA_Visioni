package cinema;

import java.io.Serializable;

public class Film implements Serializable {
    private String titolo;
    private int durata;
    private String genere;
    private String descrizione;
    private Sala occupazione = new Sala();

    public Film(String titolo, int durata, String genere, String descrizione) {
        this.titolo = titolo;
        this.durata = durata;
        this.genere = genere;
        this.descrizione = descrizione;
    }

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public int getDurata() {
        return durata;
    }

    public void setDurata(int durata) {
        this.durata = durata;
    }

    public String getGenere() {
        return genere;
    }

    public void setGenere(String genere) {
        this.genere = genere;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public Sala getOccupazione() {
        return occupazione;
    }
}
