package cinema;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;

public class CinemaGUI extends JFrame {

    private final ArrayList<Film> films;
    private DefaultListModel<String> filmListModel;
    private JList<String> filmList;
    private JPanel seatPanel;
    private JPanel mainPanel;
    private JPanel filmDetailsPanel;
    private JLabel titleLabel, durationLabel, genreLabel, descriptionLabel;
    private JTextArea descriptionArea;
    private Film currentFilm;
    private JLabel statusLabel;
    private final Color AVAILABLE_SEAT_COLOR = Color.LIGHT_GRAY;
    private final Color OCCUPIED_SEAT_COLOR = Color.RED;
    private final Color VIP_SEAT_COLOR = Color.YELLOW;
    private final Color RECLINABLE_SEAT_COLOR = Color.GREEN;

    public CinemaGUI() {
        // Carica i film
        films = Cinema.loadFilms();

        // Configurazione finestra principale
        setTitle("NEBULA Visioni");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);

        // Inizializzazione del layout principale
        mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(mainPanel);

        // Left Panel (Film List)
        createFilmListPanel();

        // Center Panel (Film Details and Seat Map)
        createCenterPanel();

        // Status Label
        statusLabel = new JLabel(" ");
        mainPanel.add(statusLabel, BorderLayout.SOUTH);

        // Mostra la finestra
        setVisible(true);
    }

    private void createFilmListPanel() {
        // Pannello lista film (sinistra)
        JPanel filmListPanel = new JPanel(new BorderLayout());
        filmListPanel.setBorder(BorderFactory.createTitledBorder("Film Disponibili"));
        
        // Impostiamo una larghezza fissa al pannello dei film
        filmListPanel.setPreferredSize(new Dimension(200, 0));

        filmListModel = new DefaultListModel<>();
        updateFilmList();

        filmList = new JList<>(filmListModel);
        filmList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        filmList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int selectedIndex = filmList.getSelectedIndex();
                if (selectedIndex != -1) {
                    showFilmDetails(films.get(selectedIndex));
                }
            }
        });

        JScrollPane listScrollPane = new JScrollPane(filmList);
        filmListPanel.add(listScrollPane, BorderLayout.CENTER);

        // Bottone per uscire
        JPanel listButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        JButton exitButton = new JButton("Esci");
        exitButton.addActionListener(e -> {
            Cinema.saveFilms(films);
            System.exit(0);
        });

        listButtonPanel.add(exitButton);
        filmListPanel.add(listButtonPanel, BorderLayout.SOUTH);

        // Aggiungi il pannello al main panel
        mainPanel.add(filmListPanel, BorderLayout.WEST);
    }

    private void createCenterPanel() {
        // Pannello centrale (dettagli film e mappa posti)
        JPanel centerPanel = new JPanel(new BorderLayout());

        // Pannello dettagli film
        filmDetailsPanel = new JPanel();
        filmDetailsPanel.setLayout(new BoxLayout(filmDetailsPanel, BoxLayout.Y_AXIS));
        filmDetailsPanel.setBorder(BorderFactory.createTitledBorder("Dettagli Film"));

        titleLabel = new JLabel("Titolo: ");
        durationLabel = new JLabel("Durata: ");
        genreLabel = new JLabel("Genere: ");
        descriptionLabel = new JLabel("Descrizione: ");

        descriptionArea = new JTextArea(5, 20);
        descriptionArea.setLineWrap(true);
        descriptionArea.setWrapStyleWord(true);
        descriptionArea.setEditable(false);
        JScrollPane descScrollPane = new JScrollPane(descriptionArea);

        filmDetailsPanel.add(titleLabel);
        filmDetailsPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        filmDetailsPanel.add(durationLabel);
        filmDetailsPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        filmDetailsPanel.add(genreLabel);
        filmDetailsPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        filmDetailsPanel.add(descriptionLabel);
        filmDetailsPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        filmDetailsPanel.add(descScrollPane);

        centerPanel.add(filmDetailsPanel, BorderLayout.NORTH);

        // Pannello posti
        JPanel seatContainer = new JPanel(new BorderLayout());
        seatContainer.setBorder(BorderFactory.createTitledBorder("Mappa Posti"));

        seatPanel = new JPanel(new GridLayout(6, 16, 5, 5));
        seatContainer.add(seatPanel, BorderLayout.CENTER);

        // Pannello legenda
        JPanel legendPanel = new JPanel();
        legendPanel.add(createLegendItem("Standard", AVAILABLE_SEAT_COLOR));
        legendPanel.add(createLegendItem("Occupato", OCCUPIED_SEAT_COLOR));
        legendPanel.add(createLegendItem("VIP", VIP_SEAT_COLOR));
        legendPanel.add(createLegendItem("Reclinabile", RECLINABLE_SEAT_COLOR));

        seatContainer.add(legendPanel, BorderLayout.SOUTH);

        centerPanel.add(seatContainer, BorderLayout.CENTER);

        // Aggiungi il pannello al main panel
        mainPanel.add(centerPanel, BorderLayout.CENTER);
    }

    private JPanel createLegendItem(String text, Color color) {
        JPanel item = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JPanel colorSquare = new JPanel();
        colorSquare.setPreferredSize(new Dimension(15, 15));
        colorSquare.setBackground(color);
        item.add(colorSquare);
        item.add(new JLabel(text));
        return item;
    }

    private void updateFilmList() {
        filmListModel.clear();
        for (Film film : films) {
            filmListModel.addElement(film.getTitolo());
        }
    }

    private void showFilmDetails(Film film) {
        currentFilm = film;

        titleLabel.setText("Titolo: " + film.getTitolo());
        durationLabel.setText("Durata: " + film.getDurata() + " minuti");
        genreLabel.setText("Genere: " + film.getGenere());
        descriptionArea.setText(film.getDescrizione());

        updateSeatMap();
    }

    private void updateSeatMap() {
        if (currentFilm == null) {
            return;
        }

        seatPanel.removeAll();

        Sala sala = currentFilm.getOccupazione();
        for (int i = 0; i < 6; i++) {
            char row = (char) ('A' + i);
            for (int j = 0; j < 16; j++) {
                final int finalJ = j;
                JButton seatButton = new JButton(row + "" + finalJ);
                seatButton.setPreferredSize(new Dimension(40, 30));
                seatButton.setMargin(new Insets(0, 0, 0, 0));

                // Determina il tipo di poltrona in base alla riga
                if (i < 2) {
                    // Poltrona normale (A-B)
                    seatButton.setBackground(AVAILABLE_SEAT_COLOR);
                } else if (i < 4) {
                    // Poltrona reclinabile (C-D)
                    seatButton.setBackground(RECLINABLE_SEAT_COLOR);
                } else {
                    // Poltrona VIP (E-F)
                    seatButton.setBackground(VIP_SEAT_COLOR);
                }

                // Controlliamo lo stato del posto utilizzando il metodo corretto della sala
                String rowStr = String.valueOf(row);
                boolean isOccupato = sala.isSeatOccupied(rowStr, finalJ);

                if (isOccupato) {
                    // Il posto è occupato
                    seatButton.setBackground(OCCUPIED_SEAT_COLOR);
                }

                seatButton.addActionListener(e -> {
                    selectSeat(row, finalJ);
                });

                seatPanel.add(seatButton);
            }
        }

        seatPanel.revalidate();
        seatPanel.repaint();
    }

    private void selectSeat(char row, int col) {
        if (currentFilm == null) {
            return;
        }

        Sala sala = currentFilm.getOccupazione();
        String rowStr = String.valueOf(row);

        // Controlliamo se il posto è occupato usando il metodo della classe Sala
        boolean isOccupato = sala.isSeatOccupied(rowStr, col);

        if (isOccupato) {
            // Il posto è già occupato
            statusLabel.setText("Il posto " + row + col + " è già occupato");
        } else {
            // Il posto è libero

            // Otteniamo il prezzo
            int price = sala.getPriceOfSeat(rowStr, col);

            // Chiediamo conferma
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Vuoi prenotare il posto " + row + col + " per il film \"" + currentFilm.getTitolo() + "\"?\n"
                    + "Prezzo: " + price + "€",
                    "Conferma prenotazione",
                    JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                if (sala.bookSeat(rowStr, col) == 0) {
                    JOptionPane.showMessageDialog(this, "Prenotazione effettuata con successo", "Prenotazione", JOptionPane.INFORMATION_MESSAGE);
                    updateSeatMap(); // Aggiorniamo la mappa dei posti
                } else {
                    JOptionPane.showMessageDialog(this, "Errore nella prenotazione", "Errore", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
}