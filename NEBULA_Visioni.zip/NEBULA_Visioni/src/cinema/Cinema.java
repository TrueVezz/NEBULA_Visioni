package cinema;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.SwingUtilities;

public class Cinema {

    private static final String FILE_NAME = "films.ser";

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Scegli la modalità di esecuzione:");
        System.out.println("1. Interfaccia a linea di comando");
        System.out.println("2. Interfaccia grafica");

        int scelta = input.nextInt();
        if (scelta == 2) {
            // Avvia l'interfaccia grafica
            SwingUtilities.invokeLater(() -> new CinemaGUI());
        } else {
            // Codice originale dell'interfaccia a linea di comando
            ArrayList<Film> films = loadFilms(); // Carica da file se esiste

            do {
                System.out.println(printGeneralMenu());
                scelta = input.nextInt();
                input.nextLine(); // consume newline
                switch (scelta) {
                    case 1 -> {
                        System.out.println(printManageFilmMenu());
                        int subScelta = input.nextInt();
                        input.nextLine(); // consume newline
                        switch (subScelta) {
                            case 1 ->
                                films.add(createFilm(input));
                            case 2 -> {
                                System.out.println("Titolo del film da cancellare:");
                                String titolo = input.nextLine();
                                Film f = searchFilmByTitle(films, titolo);
                                if (f != null) {
                                    films.remove(f);
                                    System.out.println("Film rimosso.");
                                } else {
                                    System.out.println("Film non trovato.");
                                }
                            }
                            case 3 -> {
                                for (Film f : films) {
                                    System.out.println(f.getTitolo());
                                    System.out.println(f.getOccupazione().printSeat());
                                    System.out.println("\n\n");
                                }
                            }
                            default ->
                                System.out.println("Comando non riconosciuto.");
                        }
                    }
                    case 2 ->
                        System.out.println(printFilm(films));

                    case 3 -> {
                        System.out.println("Inserire il titolo del film da prenotare:");
                        String title = input.nextLine();
                        Film f = searchFilmByTitle(films, title);

                        if (f == null) {
                            System.out.println("Film non trovato.");
                            break;
                        }

                        System.out.println(f.getOccupazione().printSeat());
                        System.out.print("Inserire fila: ");
                        String fila = input.nextLine().toUpperCase();
                        System.out.print("Inserire numero: ");
                        int num = input.nextInt();
                        input.nextLine();

                        System.out.println("Prezzo: " + f.getOccupazione().getPriceOfSeat(fila, num));
                        System.out.println("-1- per continuare");
                        int continua = input.nextInt();
                        input.nextLine();

                        if (continua == 1) {
                            if (f.getOccupazione().bookSeat(fila, num) == 0) {
                                System.out.println("Prenotazione avvenuta con successo.");
                            } else {
                                System.out.println("Posto già prenotato.");
                            }
                        } else {
                            System.out.println("Prenotazione annullata.");
                        }
                    }

                    case 4 -> {
                        saveFilms(films);
                        System.out.println("Uscita. Dati salvati.");
                    }

                    default ->
                        System.out.println("Comando non riconosciuto.");
                }

            } while (scelta != 4);
        }
    }
    // Menu

    public static String printGeneralMenu() {
        return """
            1) Gestione Film
            2) Stampa film
            3) Prenota un posto
            4) Uscita
            """;
    }

    public static String printManageFilmMenu() {
        return """
            1) Aggiungi film
            2) Rimuovi film
            """;
    }

    // Crea un nuovo film
    public static Film createFilm(Scanner input) {
        System.out.print("Titolo: ");
        String titolo = input.nextLine();
        System.out.print("Durata (minuti): ");
        int durata = input.nextInt();
        input.nextLine();
        System.out.print("Genere: ");
        String genere = input.nextLine();
        System.out.print("Descrizione: ");
        String descrizione = input.nextLine();

        return new Film(titolo, durata, genere, descrizione);
    }

    // Stampa titoli
    public static String printFilm(ArrayList<Film> film) {
        StringBuilder sb = new StringBuilder();
        for (Film f : film) {
            sb.append(f.getTitolo()).append("\n");
        }
        return sb.toString();
    }

    // Ricerca per titolo
    public static Film searchFilmByTitle(ArrayList<Film> film, String title) {
        for (Film f : film) {
            if (f.getTitolo().equalsIgnoreCase(title)) {
                return f;
            }
        }
        return null;
    }

    // Serializzazione - Salvataggio
    public static void saveFilms(ArrayList<Film> films) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(films);
        } catch (IOException e) {
            System.out.println("Errore nel salvataggio dei dati: " + e.getMessage());
        }
    }

    // Serializzazione - Caricamento
    public static ArrayList<Film> loadFilms() {
        File file = new File(FILE_NAME);
        if (!file.exists()) {
            return new ArrayList<>();
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (ArrayList<Film>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Errore nel caricamento dei dati: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}
