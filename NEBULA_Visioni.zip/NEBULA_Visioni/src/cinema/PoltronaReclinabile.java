package cinema;

import java.io.Serializable;

public class PoltronaReclinabile extends Poltrona implements Serializable {

    private static final int prezzoReclinabile = 10;
    private static final String COLOR = "GREEN"; // per interfacce grafiche

    public static int getPrezzoReclinabile() {
        return prezzoReclinabile;
    }

    public PoltronaReclinabile(char fila, int numero) {
        super(fila, numero);
    }
}
